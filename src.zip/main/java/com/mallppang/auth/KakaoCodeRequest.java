package com.mallppang.auth;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class KakaoCodeRequest {
	private String code;
}
