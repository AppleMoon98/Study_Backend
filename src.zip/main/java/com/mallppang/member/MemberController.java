package com.mallppang.member;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/member")
@RequiredArgsConstructor
public class MemberController {
	
//	private final MemberService memberService;
	
//	private ResponseEntity<Long> register(@RequestBody MemberRegisterRequest req)
	
	
}
