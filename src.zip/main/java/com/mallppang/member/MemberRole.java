package com.mallppang.member;

public enum MemberRole {
	ADMIN, SELLER, MEMBER
}
