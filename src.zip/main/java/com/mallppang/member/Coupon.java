package com.mallppang.member;

import java.time.LocalDateTime;

public class Coupon {
    private String name;
    private int rate;
    private LocalDateTime startDate;
    private LocalDateTime endDate;
}
