package com.mallppang.util;

public class CustomJWTExcaption extends RuntimeException{
	public CustomJWTExcaption(String msg) {
		super(msg);
	}
}
