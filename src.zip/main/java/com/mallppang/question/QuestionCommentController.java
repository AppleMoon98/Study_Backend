package com.mallppang.question;

import java.util.List;
import java.util.Map;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mallppang.member.MemberDTO;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@RestController
@RequiredArgsConstructor
@Log4j2
@RequestMapping("/qc")
public class QuestionCommentController {
	private final QuestionCommentService CommentService;

	// 댓글 등록
	@PostMapping("/{boardId}")
	public Map<String, Long> register(@RequestBody QuestionCommentDTO questionDTO, @PathVariable("boardId") Long boardId, @AuthenticationPrincipal MemberDTO memberDTO){
		Long logNum = CommentService.register(questionDTO, boardId);
		return Map.of("결과", logNum);
	}

	// 댓글 수정
	@PutMapping("/{id}")
	public Map<String, String> modify(@PathVariable("id") Long id, QuestionCommentDTO questionDTO) {
		questionDTO.setId(id);
		CommentService.modify(questionDTO);
		return Map.of("수정", "성공");
	}

	// 댓글 삭제
	@DeleteMapping("/{id}")
	public Map<String, String> delete(@PathVariable("id") Long id) {
		CommentService.delete(id);
		
		return Map.of("삭제", "성공");
	}
	
	// 댓글 리스트 받기
	@GetMapping("/{boardId}")
	public List<QuestionCommentDTO> getList(@PathVariable("boardId") Long boardId){
		return CommentService.getList(boardId);
	}
}
