package com.mallppang.security;

import java.util.stream.Collectors;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.mallppang.member.Member;
import com.mallppang.member.MemberDTO;
import com.mallppang.member.MemberRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
@RequiredArgsConstructor
public class CustomUserDetailsService implements UserDetailsService {
	private final MemberRepository memberRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		log.info("-".repeat(30) + "loadUserByUsername" + "-".repeat(30));

		Member member = memberRepository.getWithRoles(username);
		
		if (member == null)
			throw new UsernameNotFoundException("NOT FOUND");
		
		MemberDTO memberDTO = new MemberDTO(member.getEmail(), member.getPassword(), member.getNickname(),
				member.isSocial(),
				member.getMemberRoleList().stream().map(memberRole -> memberRole.name()).collect(Collectors.toList()),member.getTelNum());
		
		log.info(memberDTO);
		return memberDTO;
	}
}
