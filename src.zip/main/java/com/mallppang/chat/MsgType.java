package com.mallppang.chat;

public enum MsgType {
	TEXT, IMAGE, FILE, SYSTEM
}
