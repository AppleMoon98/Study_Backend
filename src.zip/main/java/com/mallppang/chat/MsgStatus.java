package com.mallppang.chat;

public enum MsgStatus {
	SENT,				// 메세지를 전송
	DELIVERED,		// 메세지가 도착
	READ				// 메세지를 읽음
}
